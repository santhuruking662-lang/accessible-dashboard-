const menuButton = document.getElementById("menuButton");
const mainNav = document.getElementById("mainNav");

if (menuButton && mainNav) {
  menuButton.addEventListener("click", () => {
    const hidden = mainNav.hasAttribute("hidden");
    if (hidden) {
      mainNav.removeAttribute("hidden");
      menuButton.setAttribute("aria-expanded", "true");
    } else {
      mainNav.setAttribute("hidden", "");
      menuButton.setAttribute("aria-expanded", "false");
    }
  });
}

const form = document.getElementById("contactForm");
const formMessage = document.getElementById("formMessage");

if (form) {
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    if (!form.checkValidity()) {
      formMessage.textContent = "Please complete all required fields correctly.";
      form.reportValidity();
      return;
    }
    formMessage.textContent = "Form submitted successfully.";
    form.reset();
  });
}

const modal = document.getElementById("infoModal");
const openModal = document.getElementById("openModal");
const closeModal = document.getElementById("closeModal");

if (modal && openModal && closeModal) {
  openModal.addEventListener("click", () => modal.showModal());
  closeModal.addEventListener("click", () => modal.close());
}
